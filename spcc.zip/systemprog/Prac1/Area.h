#define areaOfSquare(side) side * side

#define areaOfRectangle(length, breadth) length * breadth

#define areaOfTriange(base, height) (base * height) / 2

#define areaOfCircle(radius) 3.1415 * radius * radius