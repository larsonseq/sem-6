#include<math.h>

#define add(a, b) a+b

#define sub(a, b) a-b

#define multiply(a, b) a * b

#define divide(a, b) a / b

#define power(a, b) pow(a, b)

#define square(a) pow(a, 2)

#define cube(a) pow(a, 3)

#define root2(a) sqrt(a)

#define root3(a) pow(a, (double)1/3)
