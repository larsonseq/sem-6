#include<stdio.h>
#include"Fact.h"

int main() {
    int i;
    unsigned long int f = 1;
    printf("Enter Number: ");
    int num;
    scanf("%ld", &num);
    fact(num)
    return 0;
}